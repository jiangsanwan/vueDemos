/**
 * @description 导出自定义配置
 **/
const config = {
  layout: 'vertical',
  donation: true,
  templateFolder: 'project',
}
module.exports = config
