<template>
	<div class="vue-router">vue-router</div>
</template>

<script type="text/ecmascript-6">
	export default {
        name: 'VueRouter',
		setup () {
			return {
				// 
			}
		}
	}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">
	
</style>